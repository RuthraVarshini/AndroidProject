package com.example.finalproject;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.itemactivity);

        // Get the category passed from the previous activity
        String category = getIntent().getStringExtra("category");

        // Display the category in a TextView
        TextView categoryTextView = findViewById(R.id.categoryTextView);
        categoryTextView.setText(category);

        // Get the LinearLayout to add buttons and input widgets
        LinearLayout buttonLayout = findViewById(R.id.buttonLayout);

        // Get the list of button texts from the previous activity
        ArrayList<String> buttonTexts = getIntent().getStringArrayListExtra("buttonTexts");

        // Iterate through each button text and create a button with an input widget
        for (String text : buttonTexts) {
            // Create a new button
            Button button = new Button(this);
            button.setText(text);

            // Create an EditText for input
            EditText editText = new EditText(this);

            // Add button and input widget to the LinearLayout
            buttonLayout.addView(button);
            buttonLayout.addView(editText);
        }
    }
}
