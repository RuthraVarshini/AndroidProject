package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class expense extends AppCompatActivity {

    private EditText editText;
    private LinearLayout categoryOptions;
    private ArrayList<String> buttonTexts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.expense);
        categoryOptions = findViewById(R.id.categoryOptions);
        Button addButton = findViewById(R.id.btnAdd);
        editText = findViewById(R.id.editText);

        // Add existing buttons to the ArrayList
        addButtonToList(findViewById(R.id.btnEducation));
        addButtonToList(findViewById(R.id.btnFood));
        addButtonToList(findViewById(R.id.btnTransport));

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewButton();
            }
        });

        Button btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String category = editText.getText().toString().trim();
                if (!category.isEmpty()) {
                    navigateToItemActivity(category);
                }
            }
        });
    }

    private void addButtonToList(Button button) {
        buttonTexts.add(button.getText().toString());
    }

    private void addNewButton() {
        String buttonText = editText.getText().toString().trim();
        if (!buttonText.isEmpty()) {
            buttonTexts.add(buttonText);
            // Create a new button and set its properties
            Button newButton = new Button(this);
            newButton.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            newButton.setText(buttonText);

            // Add the new button to the layout
            categoryOptions.addView(newButton);

            // Clear the edit text
            editText.setText("");
        }
    }

    private void navigateToItemActivity(String category) {
        Intent intent = new Intent(expense.this, ItemActivity.class);
        intent.putExtra("category", category);
        intent.putStringArrayListExtra("buttonTexts", buttonTexts);
        startActivity(intent);
    }
}
