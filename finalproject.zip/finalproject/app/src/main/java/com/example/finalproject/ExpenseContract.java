package com.example.finalproject;

import android.provider.BaseColumns;

public final class ExpenseContract {
    private ExpenseContract() {} // To prevent instantiation

    public static class ExpenseEntry implements BaseColumns {
        public static final String TABLE_NAME = "expenses";
        public static final String COLUMN_NAME_DESCRIPTION = "description";
    }
}
