package com.example.finalproject;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class income extends AppCompatActivity {

    private EditText editText;
    private LinearLayout categoryOptions;
    private ExpenseDBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.income);

        // Initialize views
        categoryOptions = findViewById(R.id.categoryOptions);
        editText = findViewById(R.id.editText);

        // Initialize ExpenseDBHelper
        dbHelper = new ExpenseDBHelper(this);

        // Add button click listener
        Button addButton = findViewById(R.id.btnAdd);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewButton();
            }
        });

        // Submit button click listener
        Button btnSubmit = findViewById(R.id.btnSubmit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add your logic to handle submission, if needed
                // For example, you can save the entered income category to a database
                String category = editText.getText().toString().trim();
                if (!category.isEmpty()) {
                    saveIncomeCategory(category);
                } else {
                    Toast.makeText(income.this, "Please enter a category", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Method to add a new income category button
    private void addNewButton() {
        String buttonText = editText.getText().toString().trim();
        if (!buttonText.isEmpty()) {
            // Create a new button and set its properties
            Button newButton = new Button(this);
            newButton.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            newButton.setText(buttonText);
            newButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Handle button click if needed
                    // For example, you can open a new activity or perform some action
                }
            });

            // Add the new button to the layout
            categoryOptions.addView(newButton);

            // Clear the edit text
            editText.setText("");
        } else {
            Toast.makeText(this, "Please enter a category", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to save the income category to a database
    private void saveIncomeCategory(String category) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ExpenseContract.ExpenseEntry.COLUMN_NAME_DESCRIPTION, category);
        long newRowId = db.insert(ExpenseContract.ExpenseEntry.TABLE_NAME, null, values);
        db.close();
        if (newRowId != -1) {
            Toast.makeText(this, "Income category saved successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to save income category", Toast.LENGTH_SHORT).show();
        }
    }
}
